/* Main interactions and animations for SONY ELECTRONICS
   - Loader handling
   - AOS init
   - GSAP intro animations
   - Particles canvas background
   - Menu, search, theme toggles
   - Product filters and search
   - WhatsApp enquiry integration
   - Product details toggle
   - Full quality implementation
*/

// ============================================
// PUBLIC FUNCTIONS
// ============================================

// Toggle product details - simple instant toggle
function toggleDetails(btn) {
  try {
    // Find the product-details div within the same card
    const card = btn.closest('.product-card');
    if (!card) {
      console.warn('❌ Product card not found for button', btn);
      return;
    }
    
    const details = card.querySelector('.product-details');
    if (!details) {
      console.warn('❌ Product details div not found in card');
      return;
    }
    
    // Simple toggle without animation
    details.classList.toggle('hidden');
    const isHidden = details.classList.contains('hidden');
    
    // Update button text
    btn.textContent = isHidden ? '📋 Details' : '✕ Close';
    
    console.log('✅ Product details toggled:', isHidden ? 'hidden' : 'visible');
  } catch (error) {
    console.error('❌ Error in toggleDetails:', error);
  }
}

// Open WhatsApp with product enquiry
function openWhatsApp(product) {
  try {
    const phone = '919059380340';
    const message = encodeURIComponent(`Hi! I'm interested in ${product}. Can you provide more details and pricing?`);
    const url = `https://wa.me/${phone}?text=${message}`;
    window.open(url, '_blank');
    console.log('✅ WhatsApp opened for product:', product);
  } catch (error) {
    console.error('❌ Error opening WhatsApp:', error);
  }
}

// ============================================
// DOM READY - INITIALIZE ALL
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  console.log('🚀 Initializing SONY ELECTRONICS...');
  
  // ============================================
  // GET DOM ELEMENTS
  // ============================================
  const loader = document.getElementById('loader');
  const enterBtn = document.getElementById('enterBtn');
  const intro = document.getElementById('intro');
  const hamburger = document.getElementById('hamburger');
  const navLinks = document.getElementById('navLinks');
  const searchToggle = document.getElementById('searchToggle');
  const searchWrap = document.getElementById('searchWrap');
  const searchClose = document.getElementById('searchClose');
  const searchInput = document.getElementById('searchInput');
  const themeToggle = document.getElementById('themeToggle');
  const filterBtns = document.querySelectorAll('.filter-btn');
  const productGrid = document.getElementById('productGrid');
  const productCards = document.querySelectorAll('.product-card');
  const backTop = document.getElementById('backTop');
  const whatsappFloat = document.getElementById('whatsappFloat');

  const whatsappPhone = '919059380340';

  // ============================================
  // LOADER - Hide after page load
  // ============================================
  if (loader) {
    window.addEventListener('load', () => {
      setTimeout(() => {
        loader.style.opacity = '0';
        loader.style.transition = 'opacity 0.6s ease';
        setTimeout(() => {
          loader.style.display = 'none';
        }, 600);
      }, 500);
    });
  }

  // ============================================
  // AOS - Scroll animations
  // ============================================
  if (window.AOS) {
    AOS.init({
      duration: 800,
      once: true,
      offset: 120
    });
    console.log('✅ AOS initialized');
  }

  // ============================================
  // Image slider autoplay
  // ============================================
  function initImageSliders() {
    const sliders = document.querySelectorAll('.image-slider');
    sliders.forEach(slider => {
      const track = slider.querySelector('.slides');
      const slides = slider.querySelectorAll('.slide');
      const dotsContainer = slider.querySelector('.slider-dots');
      if (!track || slides.length === 0 || !dotsContainer) return;

      let currentIndex = 0;
      let autoTimer = null;

      const updateSlide = (index) => {
        currentIndex = index;
        track.style.transform = `translateX(-${100 * index}%)`;
        dotsContainer.querySelectorAll('.dot').forEach((dot, dotIndex) => {
          dot.classList.toggle('active', dotIndex === index);
        });
      };

      const startAuto = () => {
        stopAuto();
        autoTimer = setInterval(() => {
          const nextIndex = (currentIndex + 1) % slides.length;
          updateSlide(nextIndex);
        }, 3500);
      };

      const stopAuto = () => {
        if (autoTimer) {
          clearInterval(autoTimer);
          autoTimer = null;
        }
      };

      slides.forEach((slide, index) => {
        const dot = document.createElement('button');
        dot.type = 'button';
        dot.className = 'dot';
        if (index === 0) dot.classList.add('active');
        dot.addEventListener('click', () => {
          updateSlide(index);
          startAuto();
        });
        dotsContainer.appendChild(dot);
      });

      slider.addEventListener('mouseenter', stopAuto);
      slider.addEventListener('mouseleave', startAuto);
      startAuto();
    });
  }

  initImageSliders();

  // ============================================
  // GSAP - Intro animations
  // ============================================
  if (window.gsap) {
    // Animate rings
    const rings = document.querySelectorAll('.ring');
    if (rings.length > 0) {
      gsap.from('.ring-1', { rotate: 0, opacity: 0, scale: 0.8, duration: 1.6, delay: 0.2 });
      gsap.from('.ring-2', { rotate: 40, opacity: 0, scale: 0.7, duration: 1.8, delay: 0.3 });
      gsap.from('.ring-3', { rotate: -30, opacity: 0, scale: 0.6, duration: 1.9, delay: 0.4 });
      
      // Continuous rotation
      rings.forEach((r, i) => {
        gsap.to(r, {
          rotation: 360 * (i % 2 ? 1 : -1),
          duration: 40 + (i * 10),
          repeat: -1,
          ease: 'linear'
        });
      });
    }

    // Animate intro text
    gsap.from('.intro-title', { y: 40, opacity: 0, duration: 1.2, delay: 0.6, ease: 'power3.out' });
    gsap.from('.intro-subtitle', { y: 20, opacity: 0, duration: 1.2, delay: 0.9 });
    
    console.log('✅ GSAP animations initialized');
  }

  // ============================================
  // INTRO - Enter button
  // ============================================
  if (enterBtn && intro) {
    enterBtn.addEventListener('click', () => {
      if (window.gsap) {
        gsap.to(intro, {
          scale: 0.98,
          opacity: 0,
          duration: 0.9,
          ease: 'power2.in',
          onComplete: () => {
            intro.style.display = 'none';
            document.body.style.overflow = 'auto';
          }
        });
      } else {
        intro.style.display = 'none';
        document.body.style.overflow = 'auto';
      }
    });
  }

  // ============================================
  // MOBILE MENU - Hamburger toggle
  // ============================================
  if (hamburger && navLinks) {
    hamburger.addEventListener('click', (e) => {
      e.stopPropagation();
      navLinks.classList.toggle('show');
      console.log('📱 Menu toggled');
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.navbar') && navLinks.classList.contains('show')) {
        navLinks.classList.remove('show');
      }
    });
  }

  // ============================================
  // SEARCH - Toggle search bar
  // ============================================
  if (searchToggle && searchWrap) {
    searchToggle.addEventListener('click', () => {
      const isVisible = searchWrap.style.display === 'flex';
      searchWrap.style.display = isVisible ? 'none' : 'flex';
      if (!isVisible && searchInput) {
        searchInput.focus();
      }
      console.log('🔍 Search toggled');
    });
  }

  if (searchClose && searchWrap) {
    searchClose.addEventListener('click', () => {
      searchWrap.style.display = 'none';
    });
  }

  // ============================================
  // SEARCH - Filter products in real-time
  // ============================================
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const query = e.target.value.toLowerCase().trim();
      let visibleCount = 0;
      
      if (productCards.length > 0) {
        productCards.forEach(card => {
          try {
            const name = card.querySelector('h3')?.textContent.toLowerCase() || '';
            const price = card.querySelector('.price')?.textContent.toLowerCase() || '';
            const specs = card.querySelector('.product-details')?.textContent.toLowerCase() || '';
            
            const matches = query === '' || 
                           name.includes(query) || 
                           price.includes(query) || 
                           specs.includes(query);
            
            card.style.display = matches ? 'block' : 'none';
            card.style.animation = matches ? 'fadeInScale 0.6s ease-out' : 'none';
            
            if (matches) visibleCount++;
          } catch (err) {
            console.warn('Error filtering card:', err);
          }
        });
        
        if (visibleCount === 0 && query !== '') {
          console.log('⚠️ No products found matching:', query);
        }
      }
    });
  }

  // ============================================
  // THEME - Toggle dark/light mode
  // ============================================
  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      document.documentElement.classList.toggle('light-mode');
      const isDark = !document.documentElement.classList.contains('light-mode');
      themeToggle.innerHTML = isDark ? '<i class="fa fa-moon"></i>' : '<i class="fa fa-sun"></i>';
      localStorage.setItem('theme', isDark ? 'dark' : 'light');
      console.log('🌙 Theme toggled to:', isDark ? 'dark' : 'light');
    });
    
    // Load saved theme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') {
      document.documentElement.classList.add('light-mode');
      themeToggle.innerHTML = '<i class="fa fa-sun"></i>';
    }
  }

  // ============================================
  // PRODUCT FILTERS
  // ============================================
  if (filterBtns.length > 0) {
    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        // Remove active from all buttons
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        const filter = btn.dataset.filter;
        let visibleCount = 0;
        
        // Filter products by category
        productCards.forEach(card => {
          const category = card.dataset.category;
          const shouldShow = filter === 'all' || category === filter;
          
          card.style.display = shouldShow ? 'block' : 'none';
          card.style.animation = shouldShow ? 'fadeInScale 0.6s ease-out' : 'none';
          
          if (shouldShow) visibleCount++;
        });
        
        console.log(`🔽 Filter applied: ${filter} (${visibleCount} products)`);
      });
    });
  }

  // ============================================
  // PRODUCT CARDS - Hover animations with GSAP
  // ============================================
  if (productCards.length > 0) {
    productCards.forEach((card, index) => {
      // Staggered fade-in on page load
      if (window.gsap) {
        gsap.from(card, {
          opacity: 0,
          y: 30,
          duration: 0.8,
          delay: index * 0.1,
          ease: 'power2.out'
        });
      }

      // Hover effects
      card.addEventListener('mouseenter', function() {
        if (window.gsap) {
          gsap.to(this, {
            duration: 0.4,
            scale: 1.05,
            ease: 'power2.out'
          });
        }
      });

      card.addEventListener('mouseleave', function() {
        if (window.gsap) {
          gsap.to(this, {
            duration: 0.4,
            scale: 1,
            ease: 'power2.out'
          });
        }
      });
    });
  }

  // ============================================
  // BACK TO TOP BUTTON
  // ============================================
  if (backTop) {
    window.addEventListener('scroll', () => {
      const shouldShow = window.scrollY > 400;
      backTop.style.display = shouldShow ? 'block' : 'none';
    });

    backTop.addEventListener('click', () => {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  }

  // ============================================
  // WHATSAPP FLOAT BUTTON
  // ============================================
  if (whatsappFloat) {
    whatsappFloat.addEventListener('click', () => {
      openWhatsApp('Sony Electronics Product');
    });
  }

  console.log('✅ SONY ELECTRONICS fully initialized!');
});

// ============================================
// PARTICLE CANVAS - Animated background
// ============================================
(function initParticles() {
  const canvas = document.getElementById('particles-canvas');
  if (!canvas) return;

  try {
    const ctx = canvas.getContext('2d');
    let w = canvas.width = window.innerWidth;
    let h = canvas.height = window.innerHeight;

    const particles = [];
    const particleCount = Math.min(80, Math.max(20, w / 20));

    function rand(min, max) {
      return Math.random() * (max - min) + min;
    }

    // Create particles
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: rand(0, w),
        y: rand(0, h),
        r: rand(0.6, 2.2),
        vx: rand(-0.2, 0.2),
        vy: rand(-0.1, 0.4),
        alpha: rand(0.06, 0.18)
      });
    }

    // Handle resize
    window.addEventListener('resize', () => {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
    });

    // Animation loop
    function animate() {
      ctx.clearRect(0, 0, w, h);

      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;

        // Wrap around screen
        if (p.y > h + 10) p.y = -10;
        if (p.x > w + 10) p.x = -10;

        // Draw particle
        ctx.beginPath();
        ctx.fillStyle = `rgba(6,182,212,${p.alpha})`;
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      });

      requestAnimationFrame(animate);
    }

    animate();
    console.log('✅ Particles animation initialized');
  } catch (error) {
    console.warn('⚠️ Could not initialize particles:', error);
  }
})();
